# 3CF Scheda Studente Project

A Pen created on CodePen.

Original URL: [https://codepen.io/JoAdo07/pen/azdZrNj](https://codepen.io/JoAdo07/pen/azdZrNj).

